flask_project/
├── app.py #라우터
├── user_database.xlsx #유저 데이터베이스
├── templates/ 
│   ├── game.html #게임 화면
│   ├── game_over.html #게임 종료 화면
│   ├── index.html #로그인+메인 화면
│   └── signup.html #회원가입 화면
├── static/
│   ├── style.css
│   └── images/
│       ├── game_over.png
│       └── title_image.png  
